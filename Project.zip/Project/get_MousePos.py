import pygame

def get_MousePos():
    return pygame.mouse.get_pos()