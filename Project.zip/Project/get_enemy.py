from Kirpich import *

def get_enemy(enemy_id,  curse, artifacts):
    if enemy_id == 1:
        return Kirpich(curse, artifacts)